# NusaInfo

Aplikasi Flutter sederhana untuk menampilkan pengumuman dari API `https://jsonplaceholder.typicode.com`.

| | |
|---|---|
| Nama | Yassin N |
| NIM | 20240040127 |
| Mata Kuliah | Pemrograman Perangkat Mobile |
| Dosen Pengampu | YULHAN WAHYUDIN, M.Kom |
| Tugas | Sesi 06 - Integrasi API dan HTTP |

## Fitur
- Daftar pengumuman (`GET /posts`) dengan `FutureBuilder` + `ListView.builder`, loading, pesan error, tombol **Coba Lagi**
- Pull-to-refresh (`RefreshIndicator`)
- Detail pengumuman + komentar (`GET /posts/{id}/comments`)
- Tambah pengumuman (`POST /posts`, `jsonEncode`) dengan validasi `GlobalKey<FormState>`
- `SnackBar` di Home setelah berhasil membuat pengumuman (`await Navigator.push()`)
- Semua request HTTP dikumpulkan di `PostService`

## Cara Menjalankan
```bash
flutter create .      # sekali saja, untuk membuat folder android/ios
flutter pub get
flutter run
```

## Struktur Folder
```
lib/
├── models/post.dart
├── services/post_service.dart
├── screens/
│   ├── home_screen.dart
│   ├── detail_screen.dart
│   └── add_post_screen.dart
└── main.dart
```

## Screenshot
> Catatan: gambar di folder `screenshots/` adalah ilustrasi tampilan. Ganti dengan screenshot asli dari emulator/HP (nama file boleh sama).

### Home Screen
![Home](screenshots/01_home_screen_daftar_pengumuman.png)
### Loading
![Loading](screenshots/02_loading_indicator.png)
### Pull to Refresh
![Refresh](screenshots/08_home_pull_to_refresh.png)
### Detail Screen
![Detail](screenshots/03_detail_screen_komentar.png)
### Add Post Screen
![Form](screenshots/04_add_post_form_kosong.png) ![Validasi](screenshots/05_add_post_validasi_error.png) ![Terisi](screenshots/06_add_post_form_terisi.png)
### SnackBar setelah berhasil
![Snackbar](screenshots/07_home_snackbar_berhasil.png)
### Pesan error saat internet mati
![Error](screenshots/09_error_internet_mati_coba_lagi.png)
### Flutter Inspector
![Inspector](screenshots/10_flutter_inspector_widget_tree.png)
