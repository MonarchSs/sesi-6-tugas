import 'package:flutter/material.dart';

import '../models/post.dart';
import '../services/post_service.dart';

class DetailScreen extends StatefulWidget {
  final Post post;
  const DetailScreen({super.key, required this.post});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  final PostService _service = PostService();
  late Future<List<Comment>> _futureComments;

  @override
  void initState() {
    super.initState();
    _futureComments = _service.fetchComments(widget.post.id);
  }

  void _reload() {
    setState(() {
      _futureComments = _service.fetchComments(widget.post.id);
    });
  }

  @override
  Widget build(BuildContext context) {
    final post = widget.post;
    return Scaffold(
      appBar: AppBar(title: Text('Pengumuman #${post.id}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(post.title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text(post.body),
          const Divider(height: 32),
          Text('Komentar', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          FutureBuilder<List<Comment>>(
            future: _futureComments,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: CircularProgressIndicator()),
                );
              }
              if (snapshot.hasError) {
                final msg =
                    snapshot.error.toString().replaceFirst('Exception: ', '');
                return Column(
                  children: [
                    Text(msg, textAlign: TextAlign.center),
                    TextButton.icon(
                      onPressed: _reload,
                      icon: const Icon(Icons.refresh),
                      label: const Text('Coba Lagi'),
                    ),
                  ],
                );
              }
              final comments = snapshot.data ?? [];
              return Column(
                children: comments
                    .map((c) => Card(
                          child: ListTile(
                            title: Text(c.name,
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                            subtitle: Text('${c.email}\n${c.body}'),
                            isThreeLine: true,
                          ),
                        ))
                    .toList(),
              );
            },
          ),
        ],
      ),
    );
  }
}
