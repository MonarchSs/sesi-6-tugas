import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../models/post.dart';

/// Semua request HTTP ada di sini.
/// Urutan tiap method: (1) buat alamat -> (2) kirim request ->
/// (3) cek status code -> (4) ubah JSON menjadi objek.
class PostService {
  static const String _baseUrl = 'https://jsonplaceholder.typicode.com';
  static const Duration _timeout = Duration(seconds: 10);

  /// GET /posts
  Future<List<Post>> fetchPosts() async {
    final uri = Uri.parse('$_baseUrl/posts'); // 1. buat alamat
    final response = await _send(() => http.get(uri)); // 2. kirim request
    if (response.statusCode != 200) { // 3. cek status code
      throw Exception('Gagal memuat pengumuman (kode ${response.statusCode})');
    }
    final List<dynamic> data = jsonDecode(response.body); // 4. JSON -> objek
    return data.map((e) => Post.fromJson(e as Map<String, dynamic>)).toList();
  }

  /// GET /posts/{id}/comments
  Future<List<Comment>> fetchComments(int postId) async {
    final uri = Uri.parse('$_baseUrl/posts/$postId/comments');
    final response = await _send(() => http.get(uri));
    if (response.statusCode != 200) {
      throw Exception('Gagal memuat komentar (kode ${response.statusCode})');
    }
    final List<dynamic> data = jsonDecode(response.body);
    return data.map((e) => Comment.fromJson(e as Map<String, dynamic>)).toList();
  }

  /// POST /posts
  Future<Post> createPost({required String title, required String body}) async {
    final uri = Uri.parse('$_baseUrl/posts');
    final response = await _send(() => http.post(
          uri,
          headers: {'Content-Type': 'application/json; charset=UTF-8'},
          body: jsonEncode({'title': title, 'body': body, 'userId': 1}),
        ));
    if (response.statusCode != 201) { // 201 Created
      throw Exception('Gagal membuat pengumuman (kode ${response.statusCode})');
    }
    return Post.fromJson(jsonDecode(response.body) as Map<String, dynamic>);
  }

  /// Membungkus request agar error jaringan menjadi pesan yang ramah.
  Future<http.Response> _send(Future<http.Response> Function() request) async {
    try {
      return await request().timeout(_timeout);
    } on SocketException {
      throw Exception('Tidak ada koneksi internet. Periksa jaringan Anda.');
    } on http.ClientException {
      throw Exception('Tidak ada koneksi internet. Periksa jaringan Anda.');
    } on TimeoutException {
      throw Exception('Koneksi terlalu lama (timeout). Coba lagi.');
    }
  }
}
